export type AuthorData = {
  readonly name?: string
  readonly url?: string
  readonly icon_url?: string
}
