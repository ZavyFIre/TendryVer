export type ImageData = {
  readonly url?: string
}
