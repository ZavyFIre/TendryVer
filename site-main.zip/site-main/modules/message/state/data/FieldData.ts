export type FieldData = {
  readonly name?: string
  readonly value?: string
  readonly inline?: boolean
}
