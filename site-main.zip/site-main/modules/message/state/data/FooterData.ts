export type FooterData = {
  readonly text?: string
  readonly icon_url?: string
}
