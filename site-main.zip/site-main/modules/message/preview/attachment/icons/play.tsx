import React from "react"

export const play = (
  <svg width="24" height="24" viewBox="0 0 24 24">
    <polygon points="0 0 0 14 11 7" transform="translate(7 5)" />
  </svg>
)
