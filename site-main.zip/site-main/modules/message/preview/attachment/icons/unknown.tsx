import React from "react"
import { background, innerShadow } from "./common"

export const unknown = (
  <>
    {background}
    {innerShadow}
  </>
)
