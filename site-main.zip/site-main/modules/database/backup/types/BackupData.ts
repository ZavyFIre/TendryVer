export type BackupData = {
  id: number
  name: string
}
