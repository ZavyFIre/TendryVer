import type { ParserRule, ReactOutputRule } from "simple-markdown"

export type MarkdownRule = ParserRule & ReactOutputRule
