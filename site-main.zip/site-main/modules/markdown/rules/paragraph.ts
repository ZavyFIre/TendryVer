import { defaultRules } from "simple-markdown"
import type { MarkdownRule } from "../parsers/MarkdownRule"

export const paragraph: MarkdownRule = defaultRules.paragraph
