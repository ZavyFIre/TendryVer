import { defaultRules } from "simple-markdown"
import type { MarkdownRule } from "../parsers/MarkdownRule"

export const newline: MarkdownRule = defaultRules.newline
