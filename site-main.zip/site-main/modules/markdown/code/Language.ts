export type Language = {
  name: string
  aliases?: string[]
  dependencies?: string[]
}
