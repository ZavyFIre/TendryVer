export type Validator = (value: unknown, key: string) => string[]
