import { rgb, rgba } from "polished"
import type { ColorTheme } from "./ColorTheme"
import { COMMON_THEME } from "./commonTheme"

export const LIGHT_THEME: ColorTheme = {
  ...COMMON_THEME,
  accent: {
    primary: COMMON_THEME.discord.primary,
    warning: rgb(204, 77, 0),
    danger: rgb(217, 47, 47),
  },
  header: {
    primary: rgb(6, 6, 7),
    secondary: rgb(79, 86, 96),
  },
  text: {
    normal: rgb(49, 51, 56),
    muted: rgb(92, 94, 102),
    link: rgb(0, 108, 231),
  },
  interactive: {
    normal: rgb(79, 86, 96),
    hover: rgb(46, 51, 56),
    active: rgb(6, 6, 7),
    muted: rgb(199, 204, 209),
  },
  background: {
    primary: rgb(255, 255, 255),
    secondary: rgb(242, 243, 245),
    secondaryAlt: rgb(235, 237, 239),
    tertiary: rgb(227, 229, 232),
    accent: rgb(116, 127, 141),
    floating: rgb(255, 255, 255),
  },
  backgroundModifier: {
    hover: rgba(116, 127, 141, 0.08),
    active: rgba(116, 127, 141, 0.16),
    selected: rgba(116, 127, 141, 0.24),
    accent: rgba(6, 6, 7, 0.08),
  },
  elavation: {
    stroke: `0 0 0 1px ${rgba(6, 6, 7, 0.08)}`,
    low: [
      `0 1px 0 ${rgba(6, 6, 7, 0.1)}`,
      `0 1.5px 0 ${rgba(6, 6, 7, 0.025)}`,
      `0 2px 0 ${rgba(6, 6, 7, 0.025)}`,
    ].join(","),
    medium: `0 4px 4px ${rgba(0, 0, 0, 0.08)}`,
    high: `0 8px 16px ${rgba(0, 0, 0, 0.16)}`,
  },
  scrollbar: {
    auto: {
      thumb: rgb(204, 204, 204),
      track: rgb(242, 242, 242),
    },
    thin: {
      thumb: rgba(79, 84, 92, 0.3),
      track: rgba(0, 0, 0, 0),
    },
  },
}
