import { rgb, rgba } from "polished"
import type { ColorTheme } from "./ColorTheme"
import { COMMON_THEME } from "./commonTheme"

export const DARK_THEME: ColorTheme = {
  ...COMMON_THEME,
  accent: {
    primary: COMMON_THEME.discord.primary,
    warning: rgb(255, 217, 83),
    danger: rgb(255, 122, 107),
  },
  header: {
    primary: rgb(255, 255, 255),
    secondary: rgb(185, 187, 190),
  },
  text: {
    normal: rgb(219, 222, 225),
    muted: rgb(148, 155, 164),
    link: rgb(0, 168, 252),
  },
  interactive: {
    normal: rgb(185, 187, 190),
    hover: rgb(220, 221, 222),
    active: rgb(255, 255, 255),
    muted: rgb(79, 84, 92),
  },
  background: {
    primary: rgb(49, 51, 56),
    secondary: rgb(43, 45, 49),
    secondaryAlt: rgb(41, 43, 47),
    tertiary: rgb(32, 34, 37),
    accent: rgb(79, 84, 92),
    floating: rgb(24, 25, 28),
  },
  backgroundModifier: {
    hover: rgba(79, 84, 92, 0.16),
    active: rgba(79, 84, 92, 0.24),
    selected: rgba(79, 84, 92, 0.32),
    accent: rgba(255, 255, 255, 0.06),
  },
  elavation: {
    stroke: `0 0 0 1px ${rgba(4, 4, 5, 0.15)}`,
    low: [
      `0 1px 0 ${rgba(4, 4, 5, 0.2)}`,
      `0 1.5px 0 ${rgba(6, 6, 7, 0.05)}`,
      `0 2px 0 ${rgba(4, 4, 5, 0.05)}`,
    ].join(","),
    medium: `0 4px 4px ${rgba(0, 0, 0, 0.16)}`,
    high: `0 8px 16px ${rgba(0, 0, 0, 0.24)}`,
  },
  scrollbar: {
    auto: {
      thumb: rgb(32, 34, 37),
      track: rgb(46, 51, 56),
    },
    thin: {
      thumb: rgb(32, 34, 37),
      track: rgba(0, 0, 0, 0),
    },
  },
}
