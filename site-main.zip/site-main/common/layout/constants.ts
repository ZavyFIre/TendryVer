export const Z_INDEX_HEADER = 10
export const Z_INDEX_MODALS = 20
export const Z_INDEX_POPOVERS = 30
export const Z_INDEX_TOOLTIPS = 40
