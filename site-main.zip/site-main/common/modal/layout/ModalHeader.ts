import styled from "styled-components"

export const ModalHeader = styled.div`
  margin: 16px 16px 8px;
  display: flex;
`
